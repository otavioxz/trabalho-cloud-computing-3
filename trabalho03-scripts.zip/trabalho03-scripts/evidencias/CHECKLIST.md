# Checklist de Evidências - Trabalho 03

Capture um print (PNG/JPG) ou salve a saída em `.txt` na pasta `evidencias/`
seguindo a numeração abaixo. Cada item lista o comando exato que produz a
evidência. Rode tudo na **sua máquina** (não em ambiente do professor).

> Antes de começar: `docker compose up -d --build`

---

## 01 - Container em execução
```bash
docker ps
```
Esperado: linha com `trabalho03-linux`, status `Up`, porta `0.0.0.0:8080->80/tcp`.
Arquivo sugerido: `evidencias/01_docker_ps.png`

## 02 - Volumes Docker configurados
```bash
docker inspect trabalho03-linux --format '{{json .Mounts}}' | jq
```
(ou sem `jq`, só `docker inspect trabalho03-linux`)
Arquivo: `evidencias/02_volumes.png`

## 03 - Scripts com permissão de execução
```bash
ls -l scripts/
```
Esperado: linhas começando com `-rwxr-xr-x`.
Arquivo: `evidencias/03_perms_scripts.png`

## 04 - Atualização do sistema
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./01_update.sh"
```
Print da saída final com `[OK] Sistema atualizado.`
Arquivo: `evidencias/04_update.png`

## 05 - Instalação e validação do Apache
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./02_apache.sh"
```
Arquivo: `evidencias/05_apache.png` (precisa aparecer `Server version: Apache/...`)

## 06 - Estrutura de diretórios criada
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./03_estrutura.sh"
docker exec -it trabalho03-linux find /app/noticias -maxdepth 2
```
Arquivo: `evidencias/06_estrutura.png`

## 07 - Backup .tar.gz gerado
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./04_backup.sh"
ls -lh backups/
```
Esperado: arquivo `backup_noticias_AAAA-MM-DD_HH-MM.tar.gz`.
Arquivo: `evidencias/07_backup.png`

## 08 - Deploy realizado para /var/www/html
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./05_deploy.sh"
docker exec -it trabalho03-linux ls -la /var/www/html
```
Arquivo: `evidencias/08_deploy.png`

## 09 - Site acessível no navegador
Abra `http://localhost:8080`. Tire print da home (com a faixa azul e os cards).
Arquivo: `evidencias/09_site_navegador.png`

Também `http://localhost:8080/sobre.html`.
Arquivo: `evidencias/09b_site_sobre.png`

## 10 - Monitoramento do sistema
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./07_monitoramento.sh"
```
Precisa aparecer `[OK] CPU em X%`, `[OK] Apache em execucao`, etc.
Arquivo: `evidencias/10_monitoramento.png`

## 11 - Usuários e permissões configurados
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./08_usuarios_permissoes.sh"
docker exec -it trabalho03-linux getent group noticias_ops
docker exec -it trabalho03-linux ls -ld /app/noticias /app/noticias/publicacao
```
Arquivo: `evidencias/11_usuarios_permissoes.png`

## 12 - Processos (extra, recomendado)
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./06_processos.sh listar"
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./06_processos.sh buscar apache"
```
Arquivo: `evidencias/12_processos.png`

## 13 - Relatório final gerado
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./09_relatorio.sh"
cat logs/relatorio_execucao.txt
```
Arquivo: `evidencias/13_relatorio.png`
Também copie o `logs/relatorio_execucao.txt` para `evidencias/13_relatorio.txt`.

## 14 - Menu principal
```bash
docker exec -it trabalho03-linux bash -c "cd /app/scripts && ./menu.sh"
```
Print do menu com o cabeçalho (aluno/instituição/tema).
Arquivo: `evidencias/14_menu.png`

## 15 - Imagem publicada no DockerHub
1. Logar:
   ```bash
   docker login
   ```
2. Tagar a imagem (substituir `<usuario>`):
   ```bash
   docker tag trabalho03-scripts-trabalho03-linux <usuario>/trabalho03-linux:latest
   ```
   > Se o nome local for outro, descubra com `docker images`.
3. Publicar:
   ```bash
   docker push <usuario>/trabalho03-linux:latest
   ```
4. Print da página do repositório no DockerHub.
Arquivo: `evidencias/15_dockerhub.png`

---

## Resumo dos arquivos esperados em `evidencias/`
```
01_docker_ps.png
02_volumes.png
03_perms_scripts.png
04_update.png
05_apache.png
06_estrutura.png
07_backup.png
08_deploy.png
09_site_navegador.png
09b_site_sobre.png
10_monitoramento.png
11_usuarios_permissoes.png
12_processos.png
13_relatorio.png
13_relatorio.txt
14_menu.png
15_dockerhub.png
```

Depois de gerar tudo, atualize o link do DockerHub na seção **DockerHub** do `README.md`.
